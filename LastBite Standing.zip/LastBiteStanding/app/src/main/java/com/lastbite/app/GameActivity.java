package com.lastbite.app;

import android.os.Bundle;
import android.graphics.Canvas;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.net.PlacesClient;
import java.util.ArrayList;
import java.util.List;
import android.util.Log;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.libraries.places.api.model.AutocompletePrediction;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.model.RectangularBounds;
import com.google.android.libraries.places.api.net.FindAutocompletePredictionsRequest;
import com.google.android.libraries.places.api.net.FetchPlaceRequest;
import java.util.*;
import java.util.stream.Collectors;
import java.util.concurrent.atomic.AtomicInteger;

public class GameActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private RestaurantAdapter adapter;
    private List<RestaurantCard> restaurants;
    private List<PlayerPreference> players;
    private TextView currentPlayerText;
    private int currentPlayerIndex = 0;
    private int vetosRemaining;
    private PlacesClient placesClient;
    private double latitude;
    private double longitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        // Get data from intent
        latitude = getIntent().getDoubleExtra("latitude", 0);
        longitude = getIntent().getDoubleExtra("longitude", 0);
        players = getIntent().getParcelableArrayListExtra("players");
        vetosRemaining = players.size();

        // Initialize Places
        if (!Places.isInitialized()) {
            Places.initialize(getApplicationContext(), getString(R.string.google_maps_key));
        }
        placesClient = Places.createClient(this);

        initializeViews();
        setupRecyclerView();
        fetchRestaurants();
        updateCurrentPlayerText();
    }

    private void initializeViews() {
        currentPlayerText = findViewById(R.id.currentPlayerText);
        recyclerView = findViewById(R.id.restaurantsRecyclerView);
    }

    private void setupRecyclerView() {
        restaurants = new ArrayList<>();
        adapter = new RestaurantAdapter(restaurants);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        ItemTouchHelper.SimpleCallback swipeCallback = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView,
                                  @NonNull RecyclerView.ViewHolder viewHolder,
                                  @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getAdapterPosition();

                if (vetosRemaining > 0) {
                    adapter.removeItem(position);
                    vetosRemaining--;

                    if (vetosRemaining > 0) {
                        currentPlayerIndex = (currentPlayerIndex + 1) % players.size();
                        updateCurrentPlayerText();
                    } else {
                        showFinalResult();
                    }
                }
            }

            @Override
            public void onChildDraw(@NonNull Canvas c, @NonNull RecyclerView recyclerView,
                                    @NonNull RecyclerView.ViewHolder viewHolder,
                                    float dX, float dY, int actionState, boolean isCurrentlyActive) {
                if (actionState == ItemTouchHelper.ACTION_STATE_SWIPE) {
                    float alpha = 1.0f - Math.abs(dX) / (float) viewHolder.itemView.getWidth();
                    viewHolder.itemView.setAlpha(alpha);
                }
                super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive);
            }
        };

        new ItemTouchHelper(swipeCallback).attachToRecyclerView(recyclerView);
    }

    private void updateCurrentPlayerText() {
        if (vetosRemaining > 0) {
            PlayerPreference currentPlayer = players.get(currentPlayerIndex);
            currentPlayerText.setText(currentPlayer.name + "'s turn to veto");
        }
    }

    private void showFinalResult() {
        if (restaurants.size() == 1) {
            RestaurantCard finalChoice = restaurants.get(0);
            currentPlayerText.setText("Final Selection: " + finalChoice.getName());
            Toast.makeText(this, "Game Over! Final choice: " + finalChoice.getName(),
                    Toast.LENGTH_LONG).show();
        }
    }

    // Callback interface for restaurant fetching
    private interface RestaurantFetchCallback {
        void onRestaurantFetched();
    }

    private void fetchRestaurants() {
        Log.d("GameActivity", "Starting fetchRestaurants");
        // Create bounds for nearby search
        double radiusInDegrees = 0.02; // Roughly 2km
        final RectangularBounds searchBounds = RectangularBounds.newInstance(
                new LatLng(latitude - radiusInDegrees, longitude - radiusInDegrees),
                new LatLng(latitude + radiusInDegrees, longitude + radiusInDegrees)
        );

        // Keep track of restaurants fetched
        final AtomicInteger restaurantsFetched = new AtomicInteger(0);

        // First, fetch restaurants for player preferences
        for (PlayerPreference player : players) {
            Log.d("GameActivity", "Fetching restaurant for player: " + player.name + " cuisine: " + player.cuisine);
            findRestaurantForCuisine(player.cuisine, player.name, searchBounds, () -> {
                int fetched = restaurantsFetched.incrementAndGet();
                Log.d("GameActivity", "Restaurant fetched. Total: " + fetched + " out of " + players.size());
                if (fetched == players.size()) {
                    Log.d("GameActivity", "All player restaurants fetched, finding random recommendation");
                    findRandomHighRatedRestaurant(searchBounds);
                }
            });
        }
    }

    private void findRestaurantForCuisine(String cuisine, String playerName,
                                          RectangularBounds bounds,
                                          RestaurantFetchCallback callback) {
        Log.d("GameActivity", "Starting findRestaurantForCuisine for " + playerName);
        String query = cuisine + " restaurant";

        FindAutocompletePredictionsRequest request = FindAutocompletePredictionsRequest.builder()
                .setLocationBias(bounds)
                .setTypesFilter(Arrays.asList("restaurant"))
                .setQuery(query)
                .build();

        placesClient.findAutocompletePredictions(request)
                .addOnSuccessListener(response -> {
                    Log.d("GameActivity", "Got predictions: " + response.getAutocompletePredictions().size());
                    if (!response.getAutocompletePredictions().isEmpty()) {
                        AutocompletePrediction prediction = response.getAutocompletePredictions().get(0);
                        Log.d("GameActivity", "Selected prediction: " + prediction.getPrimaryText(null));

                        List<Place.Field> placeFields = Arrays.asList(
                                Place.Field.NAME,
                                Place.Field.RATING,
                                Place.Field.ADDRESS,
                                Place.Field.TYPES,
                                Place.Field.BUSINESS_STATUS
                        );

                        FetchPlaceRequest placeRequest = FetchPlaceRequest.builder(
                                prediction.getPlaceId(), placeFields).build();

                        placesClient.fetchPlace(placeRequest)
                                .addOnSuccessListener(placeResponse -> {
                                    Place place = placeResponse.getPlace();
                                    Log.d("GameActivity", "Got place details: " + place.getName());
                                    restaurants.add(new RestaurantCard(
                                            place.getName(),
                                            cuisine,
                                            place.getRating() != null ? place.getRating() + " ★" : "Rating N/A",
                                            place.getAddress(),
                                            "Suggested for " + playerName
                                    ));
                                    adapter.notifyDataSetChanged();
                                    callback.onRestaurantFetched();
                                })
                                .addOnFailureListener(exception -> {
                                    Log.e("GameActivity", "Place details fetch failed: " + exception.getMessage());
                                    callback.onRestaurantFetched();
                                });
                    } else {
                        Log.d("GameActivity", "No predictions found for " + cuisine);
                        callback.onRestaurantFetched();
                    }
                })
                .addOnFailureListener(exception -> {
                    Log.e("GameActivity", "Predictions fetch failed: " + exception.getMessage());
                    callback.onRestaurantFetched();
                });
    }

    private void findRandomHighRatedRestaurant(RectangularBounds bounds) {
        Log.d("GameActivity", "Finding random high-rated restaurant");
        FindAutocompletePredictionsRequest request = FindAutocompletePredictionsRequest.builder()
                .setLocationBias(bounds)
                .setQuery("restaurant rating:4.5")
                .setTypesFilter(Arrays.asList("restaurant"))
                .build();

        placesClient.findAutocompletePredictions(request)
                .addOnSuccessListener(response -> {
                    Log.d("GameActivity", "Got " + response.getAutocompletePredictions().size() + " high-rated predictions");
                    if (!response.getAutocompletePredictions().isEmpty()) {
                        Random random = new Random();
                        int index = random.nextInt(response.getAutocompletePredictions().size());
                        AutocompletePrediction prediction = response.getAutocompletePredictions().get(index);
                        Log.d("GameActivity", "Selected random prediction: " + prediction.getPrimaryText(null));

                        List<Place.Field> placeFields = Arrays.asList(
                                Place.Field.NAME,
                                Place.Field.RATING,
                                Place.Field.ADDRESS,
                                Place.Field.TYPES
                        );

                        FetchPlaceRequest placeRequest = FetchPlaceRequest.builder(
                                prediction.getPlaceId(), placeFields).build();

                        placesClient.fetchPlace(placeRequest)
                                .addOnSuccessListener(placeResponse -> {
                                    Place place = placeResponse.getPlace();
                                    Log.d("GameActivity", "Got random place details: " + place.getName());
                                    restaurants.add(new RestaurantCard(
                                            place.getName(),
                                            "Special Recommendation",
                                            place.getRating() != null ? place.getRating() + " ★" : "Rating N/A",
                                            place.getAddress(),
                                            "Game's Special Pick"
                                    ));
                                    adapter.notifyDataSetChanged();
                                })
                                .addOnFailureListener(exception ->
                                        Log.e("GameActivity", "Random place details fetch failed: " + exception.getMessage())
                                );
                    }
                })
                .addOnFailureListener(exception ->
                        Log.e("GameActivity", "Random predictions fetch failed: " + exception.getMessage())
                );
    }

    private void findHighRatedRestaurant(RectangularBounds bounds, String query) {
        FindAutocompletePredictionsRequest request = FindAutocompletePredictionsRequest.builder()
                .setLocationBias(bounds)
                .setQuery(query + " rating:4")
                .setTypesFilter(Arrays.asList("restaurant"))
                .build();

        placesClient.findAutocompletePredictions(request)
                .addOnSuccessListener(response -> {
                    if (!response.getAutocompletePredictions().isEmpty()) {
                        Random random = new Random();
                        AutocompletePrediction prediction =
                                response.getAutocompletePredictions().get(
                                        random.nextInt(response.getAutocompletePredictions().size())
                                );

                        List<Place.Field> placeFields = Arrays.asList(
                                Place.Field.NAME,
                                Place.Field.RATING,
                                Place.Field.ADDRESS,
                                Place.Field.TYPES
                        );

                        FetchPlaceRequest placeRequest = FetchPlaceRequest.builder(
                                prediction.getPlaceId(), placeFields).build();

                        placesClient.fetchPlace(placeRequest)
                                .addOnSuccessListener(placeResponse -> {
                                    Place place = placeResponse.getPlace();
                                    if (place.getRating() != null && place.getRating() >= 4.0) {
                                        restaurants.add(new RestaurantCard(
                                                place.getName(),
                                                "Our Special Pick",
                                                place.getRating() + " ★",
                                                place.getAddress(),
                                                "Game's Recommendation"
                                        ));
                                        adapter.notifyDataSetChanged();
                                    } else {
                                        findHighRatedRestaurant(bounds, query);
                                    }
                                })
                                .addOnFailureListener(exception -> {
                                    Log.e("Places", "Place details fetch failed: " + exception.getMessage());
                                });
                    }
                })
                .addOnFailureListener(exception -> {
                    Log.e("Places", "Place prediction failed: " + exception.getMessage());
                });
    }
}